# AIGRA_BACKEND

Python backend for the [AIGRA](https://github.com/MOO-DIO/AIGRA) R package
(Agentic Item Generation, Review, and Analysis). The R package provides the
user-facing interface; this folder provides the agentic generation layer:
LLM-based clone generation, language and solver checks, critic review,
rule-based screening, RAG-based style retrieval, diagram prompt handling, and
multimodal image generation.

## Contents

```
AIGRA_BACKEND/
├── aigra_backend/
│   ├── orchestrator.py        # end-to-end generation pipeline
│   ├── parsers.py             # template parsing / normalization
│   ├── llm_clients.py         # Groq, OpenAI, Gemini, Anthropic clients
│   ├── image_clients.py       # multimodal diagram generation
│   ├── rag.py                 # style-example retrieval (FAISS + sentence-transformers)
│   ├── review_rules.py        # deterministic rule-based checks
│   ├── language_guard.py      # language consistency checks
│   ├── diagram_prompt_guard.py / diagram_renderer.py / source_diagram_agent.py
│   ├── schemas.py, config.py, exporters.py, utils.py
│   └── agents/                # generator, solver, critic agents
├── requirements.txt
└── LICENSE (MIT)
```

## Installation

Used together with the AIGRA R package (>= 0.2.0):

```r
install.packages("AIGRA")
library(AIGRA)

# 1. Place this folder somewhere on your machine, e.g. C:/AIGRA_BACKEND
# 2. Create its Python environment (requires the 'uv' tool: https://docs.astral.sh/uv/)
ensure_aigra_python(backend_path = "C:/AIGRA_BACKEND")

# 3. Register and verify
aigra_set_backend("C:/AIGRA_BACKEND")
aigra_status()   # backend_import_ok should be TRUE
```

Manual alternative (any platform):

```bash
cd AIGRA_BACKEND
python -m venv .venv
.venv/Scripts/pip install -r requirements.txt    # Windows
# .venv/bin/pip install -r requirements.txt      # Linux/macOS
```

## API keys

No credentials are stored in this repository. Provider keys are read from
environment variables at run time: `GROQ_API_KEY`, `OPENAI_API_KEY`,
`GEMINI_API_KEY` (or `GOOGLE_API_KEY`), `ANTHROPIC_API_KEY`. From R they can
be set with `aigra_set_api_keys()` or passed per call via the `*.API`
arguments. Never commit keys or `.env` files.

## License

MIT — see LICENSE.
