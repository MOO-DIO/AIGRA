import csv
import json
from pathlib import Path
from typing import List

from aigra_backend.schemas import GenerationRecord


def export_jsonl(records: List[GenerationRecord], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record.model_dump(), ensure_ascii=False) + "\n")

    return path


def export_csv(records: List[GenerationRecord], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = [
        "original_id",
        "source_language",
        "target_language",
        "subject",
        "exam",
        "original_difficulty",
        "original_grade",
        "original_section",
        "original_topic",
        "original_objective",
        "clone_index",
        "clone_stem",
        "opt_A",
        "opt_B",
        "opt_C",
        "opt_D",
        "correct_option",
        "difficulty_level",
        "cognitive_level",
        "difficulty_note",
        "rationale",
        "diagram_required",
        "diagram_prompt",
        "diagram_path",
        "image_provider",
        "image_model",
        "solver_answer",
        "solver_matches_key",
        "solver_reasoning",
        "status",
        "review_comment",
        "record_note",
    ]

    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for record in records:
            original = record.original_item

            # Important: write a row even if generation failed.
            if not record.clones:
                writer.writerow(
                    {
                        "original_id": original.item_id,
                        "source_language": record.source_language,
                        "target_language": record.target_language,
                        "subject": original.subject,
                        "exam": original.exam,
                        "original_difficulty": original.difficulty,
                        "original_grade": original.grade,
                        "original_section": original.section,
                        "original_topic": original.topic,
                        "original_objective": original.objective,
                        "clone_index": "",
                        "clone_stem": "",
                        "opt_A": "",
                        "opt_B": "",
                        "opt_C": "",
                        "opt_D": "",
                        "correct_option": "",
                        "difficulty_level": "",
                        "cognitive_level": "",
                        "difficulty_note": "",
                        "rationale": "",
                        "diagram_required": "",
                        "diagram_prompt": "",
                        "diagram_path": "",
                        "image_provider": "",
                        "image_model": "",
                        "solver_answer": "",
                        "solver_matches_key": "",
                        "solver_reasoning": "",
                        "status": "pipeline_failed",
                        "review_comment": "",
                        "record_note": record.note,
                    }
                )
                continue

            for idx, clone in enumerate(record.clones, start=1):
                opts = clone.options or {}

                writer.writerow(
                    {
                        "original_id": original.item_id,
                        "source_language": record.source_language,
                        "target_language": record.target_language,
                        "subject": original.subject,
                        "exam": original.exam,
                        "original_difficulty": original.difficulty,
                        "original_grade": original.grade,
                        "original_section": original.section,
                        "original_topic": original.topic,
                        "original_objective": original.objective,
                        "clone_index": idx,
                        "clone_stem": clone.stem,
                        "opt_A": opts.get("A", ""),
                        "opt_B": opts.get("B", ""),
                        "opt_C": opts.get("C", ""),
                        "opt_D": opts.get("D", ""),
                        "correct_option": clone.correct_option,
                        "difficulty_level": clone.difficulty_level,
                        "cognitive_level": clone.cognitive_level,
                        "difficulty_note": clone.difficulty_note,
                        "rationale": clone.rationale,
                        "diagram_required": clone.diagram_required,
                        "diagram_prompt": getattr(clone, "diagram_prompt", ""),
                        "diagram_path": getattr(clone, "diagram_path", ""),
                        "image_provider": getattr(clone, "image_provider", ""),
                        "image_model": getattr(clone, "image_model", ""),
                        "solver_answer": clone.solver_answer,
                        "solver_matches_key": clone.solver_matches_key,
                        "solver_reasoning": clone.solver_reasoning,
                        "status": clone.status,
                        "review_comment": clone.review_comment,
                        "record_note": record.note,
                    }
                )

    return path
