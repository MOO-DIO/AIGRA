﻿import json
import re
from typing import Any, Dict


def extract_json_from_text(text: str) -> str:
    """
    Extract a JSON object from model output.

    Handles:
    - raw JSON
    - ```json ... ``` fenced JSON
    - text before/after JSON
    """
    if not text:
        raise ValueError("Empty model output; cannot extract JSON.")

    fence_match = re.search(
        r"```json(.*?)```",
        text,
        flags=re.DOTALL | re.IGNORECASE,
    )

    if fence_match:
        candidate = fence_match.group(1).strip()
    else:
        candidate = text.strip()

    first = candidate.find("{")
    last = candidate.rfind("}")

    if first == -1 or last == -1 or last <= first:
        raise ValueError("Could not find a JSON object in model output.")

    return candidate[first:last + 1]


def parse_json_object(text: str) -> Dict[str, Any]:
    json_text = extract_json_from_text(text)
    return json.loads(json_text)
