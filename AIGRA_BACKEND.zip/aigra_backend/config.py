﻿import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "outputs"


DEFAULT_EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
DEFAULT_GEMINI_MODEL = os.getenv("AIGRA_GEMINI_MODEL", "gemini-1.5-flash")


def get_api_key(provider: str) -> str:
    provider = provider.lower().strip()

    if provider == "gemini":
        key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not key:
            raise RuntimeError("Please set GEMINI_API_KEY or GOOGLE_API_KEY.")
        return key

    if provider == "groq":
        key = os.getenv("GROQ_API_KEY")
        if not key:
            raise RuntimeError("Please set GROQ_API_KEY.")
        return key

    if provider == "openai":
        key = os.getenv("OPENAI_API_KEY")
        if not key:
            raise RuntimeError("Please set OPENAI_API_KEY.")
        return key

    raise ValueError(f"Unknown provider: {provider}")
