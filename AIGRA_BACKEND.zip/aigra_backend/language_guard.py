
import json
import re
from typing import Any


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _extract_json(text: str):
    text = text.strip()

    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z0-9_-]*\s*", "", text)
        text = re.sub(r"\s*```$", "", text)

    start = text.find("{")
    end = text.rfind("}")

    if start == -1 or end == -1 or end <= start:
        raise ValueError("Could not find JSON object in language agent output.")

    return json.loads(text[start:end + 1])


def _is_english(language: str) -> bool:
    return _text(language).strip().lower() in {"english", "en"}


def _strict_script_instruction(target_language: str) -> str:
    lang = _text(target_language).strip().lower()

    if lang in {"russian", "???????", "ru"}:
        return (
            "For Russian output, all learner-visible natural-language words must be written in Russian using the Cyrillic alphabet. "
            "Do not use English words such as graph, time, velocity, option, series, circuit, title, country, year, school, route, answer, node, antinode, or label. "
            "Translate all learner-visible words into Russian. "
            "Keep only mathematical symbols, numbers, variables, and units unchanged where appropriate."
        )

    return (
        f"All learner-visible natural-language words must be in {target_language}. "
        "Keep only mathematical symbols, numbers, variables, and units unchanged where appropriate."
    )


def ensure_clone_language(
    clone,
    llm,
    target_language: str,
    source_language: str = "",
):
    """
    Rewrite a generated item into the target language before solver/reviewer.

    Internal option keys remain A/B/C/D for backend compatibility.
    Learner-visible option text is translated.
    Admin HTML can later display option labels as ?/?/?/? for Russian.
    """
    if _is_english(target_language):
        return clone

    stem = _text(getattr(clone, "stem", ""))
    options = getattr(clone, "options", None) or {}
    diagram_required = bool(getattr(clone, "diagram_required", False))
    diagram_prompt = _text(getattr(clone, "diagram_prompt", ""))

    system_prompt = (
        "You are the AIGRA Language Agent. "
        "You rewrite generated assessment items into the target language while preserving mathematical correctness. "
        "Return JSON only. Do not add markdown. "
        "Do not change the meaning of the item. "
        "Do not change the correct answer. "
        "Preserve internal option keys A, B, C, D exactly as JSON keys. "
        "Translate the option text values, not the option keys. "
        "Remove any prompt artifacts or system instructions from the stem. "
        + _strict_script_instruction(target_language)
    )

    user_prompt = f"""
Target language: {target_language}
Source language: {source_language}

Rewrite this generated assessment item so that all learner-visible natural language is in the target language.

Return exactly this JSON shape:
{{
  "stem": "...",
  "options": {{
    "A": "...",
    "B": "...",
    "C": "...",
    "D": "..."
  }},
  "diagram_prompt": "..."
}}

Rules:
- The stem must be in {target_language}.
- All option text must be in {target_language}.
- If diagram_prompt is present, rewrite it so all visible labels, titles, axis labels, annotations, and explanatory words requested in the diagram are in {target_language}.
- For Russian, use Cyrillic words for all natural-language labels.
- Do not use English learner-visible words in Russian output.
- Keep numbers, formulas, units, variables, and symbols such as x, y, %, cm, m, kg, ?, ?, V, A, N, m/s unchanged where appropriate.
- Do not include answer explanations.
- Do not include prompt instructions in the stem.
- Do not translate the internal JSON keys A, B, C, D.

Generated item:
Stem:
{stem}

Options:
{json.dumps(options, ensure_ascii=False)}

diagram_required:
{diagram_required}

diagram_prompt:
{diagram_prompt}
"""

    try:
        response = llm.generate(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            temperature=0,
            max_tokens=2000,
        )

        data = _extract_json(_text(response))

        new_stem = _text(data.get("stem", "")).strip()
        new_options = data.get("options", {})
        new_diagram_prompt = _text(data.get("diagram_prompt", "")).strip()

        if new_stem:
            clone.stem = new_stem

        if isinstance(new_options, dict):
            clean_options = {}
            for key in ["A", "B", "C", "D"]:
                value = new_options.get(key, options.get(key, ""))
                clean_options[key] = _text(value).strip()
            clone.options = clean_options

        if new_diagram_prompt:
            clone.diagram_prompt = new_diagram_prompt

    except Exception as e:
        old_comment = _text(getattr(clone, "review_comment", ""))
        try:
            clone.review_comment = (
                old_comment + f"\nLanguage Agent warning: {e}"
            ).strip()
        except Exception:
            pass

    return clone
