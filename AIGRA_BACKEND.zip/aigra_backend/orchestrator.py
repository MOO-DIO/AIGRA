from pathlib import Path
from typing import List, Optional
from datetime import datetime

from aigra_backend.schemas import GenerationRecord
from aigra_backend.parsers import parse_kazakhstan_physics_pdf
from aigra_backend.rag import build_vector_store, retrieve_style_examples
from aigra_backend.llm_clients import AigraLLMClient
from aigra_backend.agents.generator import generate_clones
from aigra_backend.agents.solver import attach_solver_result
from aigra_backend.agents.critic import review_clones
from aigra_backend.review_rules import apply_rule_based_review
from aigra_backend.exporters import export_csv, export_jsonl
from aigra_backend.diagram_prompt_guard import ensure_clone_diagram_prompt
from aigra_backend.language_guard import ensure_clone_language


def run_aigra_pipeline(
    pdf_path: str,
    provider: str = "groq",
    model: str = "llama-3.3-70b-versatile",
    source_language: str = "Russian",
    target_language: str = "English",
    review_language: str = "English",
    subject: str = "Physics",
    exam: str = "Kazakhstan UNT",
    n_clones: int = 1,
    max_items: Optional[int] = 1,
    output_dir: str = "outputs",
) -> List[GenerationRecord]:
    """
    Run the full AIGRA backend pipeline.

    Pipeline:
    1. Parse source PDF
    2. Build RAG store
    3. Retrieve style examples
    4. Generate clones
    5. Solve generated clones
    6. Critic review
    7. Rule-based safety review
    8. Export JSONL and CSV
    """

    pdf_path = str(pdf_path)
    output_dir_path = Path(output_dir)
    output_dir_path.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("AIGRA pipeline starting")
    print("PDF:", pdf_path)
    print("Source language:", source_language)
    print("Target language:", target_language)
    print("Provider:", provider)
    print("Model:", model)

    print("=" * 70)
    print("Parsing source items...")

    items = parse_kazakhstan_physics_pdf(
        pdf_path,
        source_language=source_language,
        subject=subject,
        exam=exam,
    )

    if max_items is not None:
        items_to_process = items[:max_items]
    else:
        items_to_process = items

    print(f"Parsed items: {len(items)}")
    print(f"Items to process: {len(items_to_process)}")

    print("=" * 70)
    print("Building RAG vector store...")

    vector_store = build_vector_store(items)

    print("=" * 70)
    print("Creating LLM client...")

    llm = AigraLLMClient(
        provider=provider,
        model=model,
    )

    records: List[GenerationRecord] = []

    for item_index, item in enumerate(items_to_process, start=1):
        print("=" * 70)
        print(f"Processing item {item_index}/{len(items_to_process)}")
        print("ID:", item.item_id)
        print("Difficulty:", item.difficulty)
        print("Topic:", item.topic)

        try:
            style_examples = retrieve_style_examples(
                vector_store=vector_store,
                item=item,
                k=3,
            )

            clones = generate_clones(
                item=item,
                style_examples=style_examples,
                llm=llm,
                target_language=target_language,
                n_clones=n_clones,
            )

            clones = [
                ensure_clone_diagram_prompt(item, clone)
                for clone in clones
            ]

            clones = [
                ensure_clone_language(
                    clone,
                    llm=llm,
                    target_language=target_language,
                    source_language=source_language,
                )
                for clone in clones
            ]

            solved_clones = []
            _aigra_original_clone_stems = {}

            for _aigra_clone_index, clone in enumerate(clones):
                _aigra_original_clone_stems[_aigra_clone_index] = getattr(clone, "stem", "")

                _aigra_diagram_required = getattr(clone, "diagram_required", False)
                _aigra_diagram_prompt = getattr(clone, "diagram_prompt", None)

                if _aigra_diagram_required and _aigra_diagram_prompt:
                    clone.stem = (
                        str(getattr(clone, "stem", ""))
                        + "\n\nDIAGRAM CONTEXT FOR SOLVING AND REVIEW:\n"
                        + str(_aigra_diagram_prompt)
                        + "\n\nTreat the diagram context above as part of the item."
                    )

                solved = attach_solver_result(
                    clone=clone,
                    llm=llm,
                    target_language=target_language,
                )
                solved_clones.append(solved)

            reviewed_clones = review_clones(
                original_item=item,
                clones=solved_clones,
                llm=llm,
                target_language=target_language,
                review_language=review_language,
            )

            final_clones = [
                apply_rule_based_review(clone)
                for clone in reviewed_clones
            ]

            # Restore clean clone stems before export.
            for _aigra_clone_index, clone in enumerate(final_clones):
                if "_aigra_original_clone_stems" in locals() and _aigra_clone_index in _aigra_original_clone_stems:
                    clone.stem = _aigra_original_clone_stems[_aigra_clone_index]

            record = GenerationRecord(
                original_item=item,
                clones=final_clones,
                source_language=source_language,
                target_language=target_language,
            )

            ok_count = sum(1 for clone in final_clones if clone.status == "ok")
            reject_count = sum(1 for clone in final_clones if clone.status == "reject")
            edited_count = sum(1 for clone in final_clones if clone.status == "edited")

            print(f"Generated clones: {len(final_clones)}")
            print(f"OK: {ok_count}; Edited: {edited_count}; Rejected: {reject_count}")

        except Exception as e:
            print(f"[ERROR] Failed item {item.item_id}: {e}")

            record = GenerationRecord(
                original_item=item,
                clones=[],
                source_language=source_language,
                target_language=target_language,
                note=f"Pipeline failed for this item: {e}",
            )

        records.append(record)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    jsonl_path = output_dir_path / f"aigra_results_{timestamp}.jsonl"
    csv_path = output_dir_path / f"aigra_results_{timestamp}.csv"

    export_jsonl(records, jsonl_path)
    export_csv(records, csv_path)

    print("=" * 70)
    print("AIGRA pipeline complete")
    print("JSONL:", jsonl_path)
    print("CSV:", csv_path)

    return records

def run_aigra_tabular_pipeline(
    file_path: str,
    provider: str = "openai",
    model: str = "gpt-4.1",
    source_language: str = "English",
    target_language: str = "English",
    review_language: str = "English",
    subject: str = "General",
    exam: str = "Item Bank",
    n_clones: int = 1,
    max_items: Optional[int] = 3,
    output_dir: str = "outputs",
) -> List[GenerationRecord]:
    """
    Run the full AIGRA backend pipeline from a CSV or Excel item bank.

    Pipeline:
    1. Parse CSV/Excel source items
    2. Build RAG store
    3. Retrieve style examples
    4. Generate clones
    5. Solve generated clones
    6. Critic review
    7. Rule-based safety review
    8. Export JSONL and CSV
    """
    from datetime import datetime
    from pathlib import Path

    from aigra_backend.parsers import parse_tabular_item_bank

    file_path = str(file_path)
    output_dir_path = Path(output_dir)
    output_dir_path.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("AIGRA tabular pipeline starting")
    print("File:", file_path)
    print("Source language:", source_language)
    print("Target language:", target_language)
    print("Provider:", provider)
    print("Model:", model)

    print("=" * 70)
    print("Parsing tabular source items...")

    items = parse_tabular_item_bank(
        file_path,
        source_language=source_language,
        subject=subject,
        exam=exam,
    )

    if max_items is not None:
        items_to_process = items[:max_items]
    else:
        items_to_process = items

    print(f"Parsed items: {len(items)}")
    print(f"Items to process: {len(items_to_process)}")

    print("=" * 70)
    print("Building RAG vector store...")

    vector_store = build_vector_store(items)

    print("=" * 70)
    print("Creating LLM client...")

    llm = AigraLLMClient(
        provider=provider,
        model=model,
    )

    records: List[GenerationRecord] = []

    for item_index, item in enumerate(items_to_process, start=1):
        print("=" * 70)
        print(f"Processing tabular item {item_index}/{len(items_to_process)}")
        print("ID:", item.item_id)
        print("Difficulty:", item.difficulty)
        print("Topic:", item.topic)

        try:
            style_examples = retrieve_style_examples(
                vector_store=vector_store,
                item=item,
                k=3,
            )

            clones = generate_clones(
                item=item,
                style_examples=style_examples,
                llm=llm,
                target_language=target_language,
                n_clones=n_clones,
            )

            clones = [
                ensure_clone_diagram_prompt(item, clone)
                for clone in clones
            ]

            clones = [
                ensure_clone_language(
                    clone,
                    llm=llm,
                    target_language=target_language,
                    source_language=source_language,
                )
                for clone in clones
            ]

            solved_clones = []
            _aigra_original_clone_stems = {}

            for _aigra_clone_index, clone in enumerate(clones):
                _aigra_original_clone_stems[_aigra_clone_index] = getattr(clone, "stem", "")

                _aigra_diagram_required = getattr(clone, "diagram_required", False)
                _aigra_diagram_prompt = getattr(clone, "diagram_prompt", None)

                if _aigra_diagram_required and _aigra_diagram_prompt:
                    clone.stem = (
                        str(getattr(clone, "stem", ""))
                        + "\n\nDIAGRAM CONTEXT FOR SOLVING AND REVIEW:\n"
                        + str(_aigra_diagram_prompt)
                        + "\n\nTreat the diagram context above as part of the item."
                    )

                solved = attach_solver_result(
                    clone=clone,
                    llm=llm,
                    target_language=target_language,
                )
                solved_clones.append(solved)

            reviewed_clones = review_clones(
                original_item=item,
                clones=solved_clones,
                llm=llm,
                target_language=target_language,
                review_language=review_language,
            )

            final_clones = [
                apply_rule_based_review(clone)
                for clone in reviewed_clones
            ]

            # Restore clean clone stems before export.
            for _aigra_clone_index, clone in enumerate(final_clones):
                if "_aigra_original_clone_stems" in locals() and _aigra_clone_index in _aigra_original_clone_stems:
                    clone.stem = _aigra_original_clone_stems[_aigra_clone_index]

            record = GenerationRecord(
                original_item=item,
                clones=final_clones,
                source_language=source_language,
                target_language=target_language,
            )

            ok_count = sum(1 for clone in final_clones if clone.status == "ok")
            reject_count = sum(1 for clone in final_clones if clone.status == "reject")
            edited_count = sum(1 for clone in final_clones if clone.status == "edited")

            print(f"Generated clones: {len(final_clones)}")
            print(f"OK: {ok_count}; Edited: {edited_count}; Rejected: {reject_count}")

        except Exception as e:
            print(f"[ERROR] Failed item {item.item_id}: {e}")

            record = GenerationRecord(
                original_item=item,
                clones=[],
                source_language=source_language,
                target_language=target_language,
                note=f"Tabular pipeline failed for this item: {e}",
            )

        records.append(record)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    jsonl_path = output_dir_path / f"aigra_tabular_results_{timestamp}.jsonl"
    csv_path = output_dir_path / f"aigra_tabular_results_{timestamp}.csv"

    export_jsonl(records, jsonl_path)
    export_csv(records, csv_path)

    print("=" * 70)
    print("AIGRA tabular pipeline complete")
    print("JSONL:", jsonl_path)
    print("CSV:", csv_path)

    return records

def run_aigra_tabular_pipeline(
    file_path: str,
    provider: str = "openai",
    model: str = "gpt-4.1",
    source_language: str = "English",
    target_language: str = "English",
    review_language: str = "English",
    subject: str = "General",
    exam: str = "Item Bank",
    n_clones: int = 1,
    max_items: Optional[int] = 3,
    output_dir: str = "outputs",
) -> List[GenerationRecord]:
    """
    Run AIGRA pipeline from CSV/Excel.

    Invalid rows are skipped and exported as pipeline_failed records.
    Valid rows continue through generation.
    """
    from datetime import datetime
    from pathlib import Path

    from aigra_backend.parsers import parse_tabular_item_bank_with_errors
    from aigra_backend.schemas import SourceItem

    file_path = str(file_path)
    output_dir_path = Path(output_dir)
    output_dir_path.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("AIGRA tabular pipeline starting")
    print("File:", file_path)
    print("Source language:", source_language)
    print("Target language:", target_language)
    print("Provider:", provider)
    print("Model:", model)

    print("=" * 70)
    print("Parsing tabular source items...")

    valid_items, invalid_rows = parse_tabular_item_bank_with_errors(
        file_path,
        source_language=source_language,
        subject=subject,
        exam=exam,
    )

    prepared_valid_items = []

    for src_item in valid_items:
        try:
            src_item = prepare_source_diagram_context(
                src_item,
                provider="gemini",
                model="gemini-3.1-pro-preview",
            )
        except Exception as e:
            old_obj = getattr(src_item, "objective", None) or ""
            src_item.objective = (
                old_obj
                + "\n\nSOURCE DIAGRAM AGENT ERROR:\n"
                + str(e)
            ).strip()

        prepared_valid_items.append(src_item)

    valid_items = prepared_valid_items

    if max_items is not None:
        items_to_process = valid_items[:max_items]
    else:
        items_to_process = valid_items

    print(f"Valid items: {len(valid_items)}")
    print(f"Invalid rows skipped: {len(invalid_rows)}")
    print(f"Items to process: {len(items_to_process)}")

    records: List[GenerationRecord] = []

    for invalid in invalid_rows:
        invalid_item = SourceItem(
            item_id=f"INVALID_ROW_{invalid['row_number']}_{invalid.get('item_id', '')}",
            stem=invalid.get("stem", ""),
            options=invalid.get(
                "options",
                {"A": "", "B": "", "C": "", "D": ""},
            ),
            correct_answer=invalid.get("correct_answer", "A"),
            difficulty=invalid.get("difficulty"),
            grade=invalid.get("grade"),
            section=invalid.get("section"),
            topic=invalid.get("topic"),
            objective=invalid.get("objective"),
            raw_metadata="",
            source_language=invalid.get("source_language", source_language),
            subject=invalid.get("subject", subject),
            exam=invalid.get("exam", exam),
        )

        records.append(
            GenerationRecord(
                original_item=invalid_item,
                clones=[],
                source_language=source_language,
                target_language=target_language,
                note=(
                    f"Invalid source row {invalid['row_number']}: "
                    + "; ".join(invalid["reasons"])
                ),
            )
        )

    if not items_to_process:
        print("No valid items to process.")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        jsonl_path = output_dir_path / f"aigra_tabular_results_{timestamp}.jsonl"
        csv_path = output_dir_path / f"aigra_tabular_results_{timestamp}.csv"

        export_jsonl(records, jsonl_path)
        export_csv(records, csv_path)

        print("=" * 70)
        print("AIGRA tabular pipeline complete")
        print("JSONL:", jsonl_path)
        print("CSV:", csv_path)

        return records

    print("=" * 70)
    print("Building RAG vector store...")

    vector_store = build_vector_store(valid_items)

    print("=" * 70)
    print("Creating LLM client...")

    llm = AigraLLMClient(
        provider=provider,
        model=model,
    )

    for item_index, item in enumerate(items_to_process, start=1):
        print("=" * 70)
        print(f"Processing tabular item {item_index}/{len(items_to_process)}")
        print("ID:", item.item_id)
        print("Difficulty:", item.difficulty)
        print("Topic:", item.topic)

        try:
            style_examples = retrieve_style_examples(
                vector_store=vector_store,
                item=item,
                k=3,
            )

            clones = generate_clones(
                item=item,
                style_examples=style_examples,
                llm=llm,
                target_language=target_language,
                n_clones=n_clones,
            )

            clones = [
                ensure_clone_diagram_prompt(item, clone)
                for clone in clones
            ]

            clones = [
                ensure_clone_language(
                    clone,
                    llm=llm,
                    target_language=target_language,
                    source_language=source_language,
                )
                for clone in clones
            ]

            solved_clones = []
            _aigra_original_clone_stems = {}

            for _aigra_clone_index, clone in enumerate(clones):
                _aigra_original_clone_stems[_aigra_clone_index] = getattr(clone, "stem", "")

                _aigra_diagram_required = getattr(clone, "diagram_required", False)
                _aigra_diagram_prompt = getattr(clone, "diagram_prompt", None)

                if _aigra_diagram_required and _aigra_diagram_prompt:
                    clone.stem = (
                        str(getattr(clone, "stem", ""))
                        + "\n\nDIAGRAM CONTEXT FOR SOLVING AND REVIEW:\n"
                        + str(_aigra_diagram_prompt)
                        + "\n\nTreat the diagram context above as part of the item."
                    )

                solved = attach_solver_result(
                    clone=clone,
                    llm=llm,
                    target_language=target_language,
                )
                solved_clones.append(solved)

            reviewed_clones = review_clones(
                original_item=item,
                clones=solved_clones,
                llm=llm,
                target_language=target_language,
                review_language=review_language,
            )

            final_clones = [
                apply_rule_based_review(clone)
                for clone in reviewed_clones
            ]

            # Restore clean clone stems before export.
            for _aigra_clone_index, clone in enumerate(final_clones):
                if "_aigra_original_clone_stems" in locals() and _aigra_clone_index in _aigra_original_clone_stems:
                    clone.stem = _aigra_original_clone_stems[_aigra_clone_index]

            record = GenerationRecord(
                original_item=item,
                clones=final_clones,
                source_language=source_language,
                target_language=target_language,
            )

            ok_count = sum(1 for clone in final_clones if clone.status == "ok")
            reject_count = sum(1 for clone in final_clones if clone.status == "reject")
            edited_count = sum(1 for clone in final_clones if clone.status == "edited")

            print(f"Generated clones: {len(final_clones)}")
            print(f"OK: {ok_count}; Edited: {edited_count}; Rejected: {reject_count}")

        except Exception as e:
            print(f"[ERROR] Failed item {item.item_id}: {e}")

            record = GenerationRecord(
                original_item=item,
                clones=[],
                source_language=source_language,
                target_language=target_language,
                note=f"Tabular pipeline failed for this item: {e}",
            )

        records.append(record)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    jsonl_path = output_dir_path / f"aigra_tabular_results_{timestamp}.jsonl"
    csv_path = output_dir_path / f"aigra_tabular_results_{timestamp}.csv"

    export_jsonl(records, jsonl_path)
    export_csv(records, csv_path)

    print("=" * 70)
    print("AIGRA tabular pipeline complete")
    print("JSONL:", jsonl_path)
    print("CSV:", csv_path)

    return records

def prepare_source_diagram_context(
    item,
    provider: str = "gemini",
    model: str = "gemini-3.1-pro-preview",
):
    """
    Add source diagram context to a SourceItem before clone generation.
    """
    from aigra_backend.source_diagram_agent import (
        source_needs_diagram,
        caption_source_diagram,
    )

    raw = getattr(item, "raw_metadata", "") or ""

    def get_meta(name):
        prefix = f"{name}="
        for line in raw.splitlines():
            if line.startswith(prefix):
                return line[len(prefix):].strip()
        return ""

    supplied_required = get_meta("source_diagram_required").lower() in {
        "true", "t", "1", "yes", "y"
    }

    source_path = get_meta("source_diagram_path")
    existing_caption = get_meta("source_diagram_caption")
    source_type = get_meta("source_diagram_type")

    detected_required = source_needs_diagram(
        stem=getattr(item, "stem", ""),
        topic=getattr(item, "topic", ""),
        objective=getattr(item, "objective", ""),
    )

    requires_diagram = supplied_required or detected_required or bool(source_path)

    if not requires_diagram:
        return item

    caption = existing_caption

    if source_path and not caption:
        caption = caption_source_diagram(
            image_path=source_path,
            stem=getattr(item, "stem", ""),
            topic=getattr(item, "topic", ""),
            provider=provider,
            model=model,
        )

    old_objective = getattr(item, "objective", None) or ""

    if caption:
        item.objective = (
            old_objective
            + "\n\nSOURCE DIAGRAM CONTEXT:\n"
            + caption
            + "\n\nWhen cloning this item, preserve the visual dependency and create a corresponding diagram_prompt for the clone."
        ).strip()

        item.raw_metadata = (
            raw
            + "\nsource_diagram_agent=captioned"
            + f"\nsource_diagram_type_used={source_type}"
            + f"\nsource_diagram_caption_used={caption}"
        ).strip()
    else:
        item.objective = (
            old_objective
            + "\n\nSOURCE DIAGRAM WARNING:\n"
            + "This item appears to require a source diagram, but no source_diagram_path or source_diagram_caption was supplied. "
            + "The clone should be marked diagram_required=true and should include a diagram_prompt if possible."
        ).strip()

        item.raw_metadata = (
            raw
            + "\nsource_diagram_agent=missing_source_diagram"
        ).strip()

    return item

