import os
from typing import Optional


class AigraLLMClient:
    """
    Provider-flexible LLM client for AIGRA.

    Supported providers:
    - groq
    - openai
    - gemini
    - anthropic
    """

    def __init__(
        self,
        provider: str = "groq",
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 120.0,
        max_retries: int = 3,
    ):
        self.provider = provider.lower().strip()
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries

        if self.provider == "groq":
            from groq import Groq

            self.model = model or "llama-3.3-70b-versatile"
            key = api_key or os.getenv("GROQ_API_KEY")

            if not key:
                raise RuntimeError("GROQ_API_KEY is not set.")

            self.client = Groq(
                api_key=key,
                timeout=timeout,
                max_retries=max_retries,
            )

        elif self.provider == "openai":
            from openai import OpenAI

            self.model = model or "gpt-4.1"
            key = api_key or os.getenv("OPENAI_API_KEY")

            if not key:
                raise RuntimeError("OPENAI_API_KEY is not set.")

            self.client = OpenAI(
                api_key=key,
                timeout=timeout,
                max_retries=max_retries,
            )

        elif self.provider == "gemini":
            from google import genai

            self.model = model or "gemini-3.1-pro-preview"
            key = (
                api_key
                or os.getenv("GEMINI_API_KEY")
                or os.getenv("GOOGLE_API_KEY")
            )

            if not key:
                raise RuntimeError("GEMINI_API_KEY or GOOGLE_API_KEY is not set.")

            self.client = genai.Client(api_key=key)

        elif self.provider == "anthropic":
            from anthropic import Anthropic

            self.model = model or "claude-sonnet-4-5"
            key = api_key or os.getenv("ANTHROPIC_API_KEY")

            if not key:
                raise RuntimeError("ANTHROPIC_API_KEY is not set.")

            self.client = Anthropic(
                api_key=key,
                timeout=timeout,
                max_retries=max_retries,
            )

        else:
            raise ValueError(
                "Unsupported provider. Use one of: "
                "'groq', 'openai', 'gemini', 'anthropic'."
            )

    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.2,
        max_tokens: int = 2048,
    ) -> str:
        if self.provider == "groq":
            return self._generate_groq(system_prompt, user_prompt, temperature, max_tokens)

        if self.provider == "openai":
            return self._generate_openai(system_prompt, user_prompt, temperature, max_tokens)

        if self.provider == "gemini":
            return self._generate_gemini(system_prompt, user_prompt, temperature, max_tokens)

        if self.provider == "anthropic":
            return self._generate_anthropic(system_prompt, user_prompt, temperature, max_tokens)

        raise ValueError(f"Unsupported provider: {self.provider}")

    def _wants_json(self, system_prompt: str, user_prompt: str) -> bool:
        joined = f"{system_prompt}\n{user_prompt}".lower()
        return (
            "json" in joined
            or "return only" in joined
            or "valid json" in joined
            or "json object" in joined
            or "json array" in joined
        )

    def _generate_groq(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )

        return response.choices[0].message.content or ""

    def _generate_openai(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        response = self.client.responses.create(
            model=self.model,
            instructions=system_prompt,
            input=user_prompt,
            temperature=temperature,
            max_output_tokens=max_tokens,
        )

        return getattr(response, "output_text", "") or ""

    def _generate_gemini(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        from google.genai import types

        config_kwargs = {
            "system_instruction": system_prompt,
            "temperature": temperature,
            "max_output_tokens": max_tokens,
        }

        # AIGRA generator/solver/critic calls usually require machine-readable JSON.
        # This asks Gemini to return clean JSON instead of markdown/prose.
        if self._wants_json(system_prompt, user_prompt):
            config_kwargs["response_mime_type"] = "application/json"

        response = self.client.models.generate_content(
            model=self.model,
            contents=[user_prompt],
            config=types.GenerateContentConfig(**config_kwargs),
        )

        text = getattr(response, "text", None)

        if text:
            return text

        parts = getattr(response, "parts", None)

        if parts is None:
            candidates = getattr(response, "candidates", []) or []
            if candidates:
                content = getattr(candidates[0], "content", None)
                parts = getattr(content, "parts", None)

        texts = []

        if parts:
            for part in parts:
                part_text = getattr(part, "text", None)
                if part_text:
                    texts.append(part_text)

        return "\n".join(texts)

    def _generate_anthropic(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        response = self.client.messages.create(
            model=self.model,
            system=system_prompt,
            messages=[
                {
                    "role": "user",
                    "content": user_prompt,
                }
            ],
            temperature=temperature,
            max_tokens=max_tokens,
        )

        parts = []

        for block in response.content:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)

        return "\n".join(parts)
