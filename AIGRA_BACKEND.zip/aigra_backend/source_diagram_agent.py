from pathlib import Path
import base64
import os


VISUAL_TRIGGERS = [
    "diagram", "figure", "shown below", "shown above",
    "shown in the figure", "graph below", "graph", "chart",
    "plot", "circuit", "ray diagram", "lens", "mirror",
    "inclined plane", "ramp", "pulley", "free-body",
    "free body", "force diagram", "velocity-time",
    "distance-time", "displacement-time", "vector",
    "trajectory", "map", "table below",
]


def source_needs_diagram(stem: str, topic: str = "", objective: str = "") -> bool:
    text = " ".join([str(stem or ""), str(topic or ""), str(objective or "")]).lower()
    return any(trigger in text for trigger in VISUAL_TRIGGERS)


def caption_source_diagram(
    image_path: str,
    stem: str = "",
    topic: str = "",
    provider: str = "gemini",
    model: str = "gemini-3.1-pro-preview",
) -> str:
    if provider.lower().strip() != "gemini":
        raise ValueError("Source diagram captioning currently supports provider='gemini'.")

    from google import genai
    from google.genai import types

    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        raise RuntimeError("GEMINI_API_KEY or GOOGLE_API_KEY is not set.")

    image_path = Path(image_path)
    if not image_path.exists():
        raise FileNotFoundError(f"Source diagram image not found: {image_path}")

    image_bytes = image_path.read_bytes()

    suffix = image_path.suffix.lower()
    if suffix in {".jpg", ".jpeg"}:
        mime = "image/jpeg"
    elif suffix == ".webp":
        mime = "image/webp"
    else:
        mime = "image/png"

    prompt = f"""
You are the Source Diagram Agent for AIGRA.

Describe the source diagram accurately for assessment item generation.

Item stem:
{stem}

Topic:
{topic}

Return a concise but complete caption that includes:
- objects, labels, axes, arrows, values, units, angles, and relationships visible in the diagram
- what the learner is expected to infer from the visual
- no answer choice and no final answer
- no extra explanation beyond the visual content

The caption must help another model generate an equivalent clone item.
"""

    client = genai.Client(api_key=key)

    response = client.models.generate_content(
        model=model,
        contents=[
            prompt,
            types.Part.from_bytes(
                data=image_bytes,
                mime_type=mime,
            ),
        ],
    )

    text = getattr(response, "text", None)
    if text:
        return text.strip()

    parts = getattr(response, "parts", None)
    if parts:
        out = []
        for part in parts:
            t = getattr(part, "text", None)
            if t:
                out.append(t)
        if out:
            return "\n".join(out).strip()

    raise RuntimeError("Gemini did not return a source diagram caption.")
