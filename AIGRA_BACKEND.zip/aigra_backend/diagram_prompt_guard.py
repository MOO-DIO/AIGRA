from typing import Any


def _text(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _has_source_diagram_context(source_item) -> bool:
    """
    Return True only when the source item truly depends on a diagram.

    Important:
    Blank metadata lines such as source_diagram_path= must NOT trigger
    diagram handling. Otherwise text-only items get prompt leakage.
    """
    raw = _text(getattr(source_item, "raw_metadata", ""))
    objective = _text(getattr(source_item, "objective", ""))
    stem = _text(getattr(source_item, "stem", ""))

    def get_meta(name: str) -> str:
        prefix = f"{name}="
        for line in raw.splitlines():
            if line.startswith(prefix):
                return line[len(prefix):].strip()
        return ""

    required_value = get_meta("source_diagram_required").lower()
    source_path = get_meta("source_diagram_path")
    source_caption = get_meta("source_diagram_caption")
    agent_status = get_meta("source_diagram_agent")

    explicitly_required = required_value in {"true", "t", "1", "yes", "y"}
    has_path = bool(source_path)
    has_caption = bool(source_caption)
    captioned_by_agent = agent_status == "captioned"

    visual_triggers = [
        "diagram below",
        "figure below",
        "shown below",
        "graph below",
        "circuit diagram",
        "ray diagram",
        "standing wave",
        "inclined plane",
        "velocity-time graph",
        "distance-time graph",
        "bar chart",
        "histogram",
        "probability tree",
        "triangle shown",
        "circle shown",
    ]

    text = "\n".join([stem, objective]).lower()
    detected_from_text = any(trigger in text for trigger in visual_triggers)

    return (
        explicitly_required
        or has_path
        or has_caption
        or captioned_by_agent
        or detected_from_text
    )


def _source_caption(source_item) -> str:
    raw = _text(getattr(source_item, "raw_metadata", ""))
    objective = _text(getattr(source_item, "objective", ""))

    markers = [
        "SOURCE DIAGRAM CONTEXT:",
        "source_diagram_caption_used=",
        "source_diagram_caption=",
    ]

    for marker in markers:
        if marker in objective:
            return objective.split(marker, 1)[1].strip()

        if marker in raw:
            return raw.split(marker, 1)[1].strip()

    return ""


def _options_text(clone) -> str:
    options = getattr(clone, "options", None) or {}
    if isinstance(options, dict):
        return "; ".join(f"{k}) {v}" for k, v in options.items())
    return _text(options)


def build_missing_diagram_prompt(source_item, clone) -> str:
    source_stem = _text(getattr(source_item, "stem", ""))
    source_topic = _text(getattr(source_item, "topic", ""))
    source_objective = _text(getattr(source_item, "objective", ""))
    source_caption = _source_caption(source_item)

    clone_stem = _text(getattr(clone, "stem", ""))
    clone_options = _options_text(clone)

    joined = " ".join([
        source_stem,
        source_topic,
        source_objective,
        source_caption,
        clone_stem,
        clone_options,
    ]).lower()

    base = (
        "Create a clean educational assessment diagram in black-and-white "
        "textbook line-art style. The diagram must contain all visual "
        "information needed to solve the item. Do not reveal the answer. "
        "Do not display answer choices A, B, C, or D. "
    )

    if any(x in joined for x in ["velocity-time", "velocity time", "graph", "axis", "axes"]):
        specific = (
            "Draw the required graph clearly. Include labelled axes with units, "
            "key plotted points, straight or curved line shape, and any marked "
            "values needed to calculate the answer. "
        )
    elif any(x in joined for x in ["circuit", "battery", "resistor", "ohm", "voltage", "current"]):
        specific = (
            "Draw the required circuit diagram clearly. Include the battery "
            "voltage, all resistor/component labels, wires, and whether the "
            "components are connected in series or parallel. "
        )
    elif any(x in joined for x in ["inclined", "plane", "block", "force", "normal", "friction", "weight"]):
        specific = (
            "Draw the required mechanics diagram clearly. Include the inclined "
            "plane or physical setup, object labels, given mass, angle, and "
            "force arrows such as weight, normal reaction, friction if present, "
            "and any resolved components needed for the item. "
        )
    elif any(x in joined for x in ["standing wave", "wave", "node", "antinode", "wavelength", "string"]):
        specific = (
            "Draw the required wave diagram clearly. Include fixed or open ends, "
            "nodes, antinodes, number of loops, total string length, and enough "
            "information for wavelength or frequency reasoning. "
        )
    elif any(x in joined for x in ["lens", "mirror", "ray", "optics", "convex", "concave"]):
        specific = (
            "Draw the required optics diagram clearly. Include the lens or mirror, "
            "principal axis, object, focal points, labelled rays, and the image "
            "position and orientation if needed. "
        )
    else:
        specific = "Include all labels, values, arrows, axes, angles, and relationships needed to solve the item. "

    return (
        base
        + specific
        + f"Clone item stem: {clone_stem}. "
        + f"Clone options for context only: {clone_options}. "
        + f"Original source diagram context: {source_caption or source_objective or source_stem}."
    )


def ensure_clone_diagram_prompt(source_item, clone):
    """
    Ensure a diagram-dependent clone has diagram_required=True and a diagram_prompt.
    This should run immediately after generation and before solver/reviewer.
    """
    requires_diagram = _has_source_diagram_context(source_item)

    existing_required = bool(getattr(clone, "diagram_required", False))
    existing_prompt = _text(getattr(clone, "diagram_prompt", "")).strip()

    if requires_diagram or existing_required:
        clone.diagram_required = True

        if not existing_prompt:
            clone.diagram_prompt = build_missing_diagram_prompt(source_item, clone)

    return clone
