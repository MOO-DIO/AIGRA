from typing import Optional
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field


class SourceItem(BaseModel):
    item_id: str
    stem: str
    options: Dict[str, str]
    correct_answer: str

    difficulty: Optional[str] = None
    grade: Optional[str] = None
    section: Optional[str] = None
    topic: Optional[str] = None
    objective: Optional[str] = None
    raw_metadata: str = ""

    source_language: str = "auto"
    subject: Optional[str] = None
    exam: Optional[str] = None


class DiagramSpec(BaseModel):
    image_specs: Optional[str] = None
    viewBox: Optional[str] = None
    alt_text: Optional[str] = None
    elements: List[Dict[str, Any]] = Field(default_factory=list)
    language: Optional[str] = None


class GeneratedItem(BaseModel):
    stem: str
    options: Dict[str, str]
    correct_option: str

    cognitive_level: Optional[str] = None
    difficulty_level: Optional[str] = None
    difficulty_note: Optional[str] = None
    rationale: Optional[str] = None

    source_language: Optional[str] = None
    target_language: str = "English"

    diagram_required: bool = False
    diagram_spec: Optional[Dict[str, Any]] = None

    diagram_prompt: Optional[str] = None

    status: Optional[str] = None
    review_comment: Optional[str] = None

    solver_answer: Optional[str] = None
    solver_reasoning: Optional[str] = None
    solver_matches_key: Optional[bool] = None


class GenerationRecord(BaseModel):
    original_item: SourceItem
    clones: List[GeneratedItem] = Field(default_factory=list)
    source_language: str = "auto"
    target_language: str = "English"
    note: Optional[str] = None
diagram_prompt: Optional[str] = None
diagram_path: Optional[str] = None
image_provider: Optional[str] = None
image_model: Optional[str] = None