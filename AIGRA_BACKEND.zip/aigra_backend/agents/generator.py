SOURCE_DIAGRAM_GENERATION_RULES = """

CRITICAL SOURCE-DIAGRAM CLONING RULE:
If the original item contains SOURCE DIAGRAM CONTEXT or SOURCE DIAGRAM WARNING:
1. The clone must set diagram_required to true.
2. The clone must include a detailed diagram_prompt.
3. The diagram_prompt must include all visual information needed to solve the item:
   - graph axes, labels, values, slopes, loops, nodes, antinodes, distances, angles, forces, circuit components, etc.
4. The clone stem must not be incomplete. If it says "diagram below", it must also include enough essential visual facts in words, or the diagram_prompt must be treated as part of the item.
5. For standing-wave items, explicitly state in the diagram_prompt:
   - number of loops/antinodes
   - fixed ends or open ends
   - total string length
   - positions of nodes if relevant
   - what quantity is being asked
6. For graph items, explicitly state in the diagram_prompt:
   - axis labels and units
   - coordinates or key values
   - line/curve shape
7. For mechanics diagrams, explicitly state:
   - object labels
   - angles
   - forces/arrows
   - masses or given values
8. Never generate a diagram-dependent clone without a solvable diagram_prompt.

"""

import json
from typing import List

from aigra_backend.schemas import SourceItem, GeneratedItem
from aigra_backend.llm_clients import AigraLLMClient
from aigra_backend.utils import parse_json_object


GENERATOR_SYSTEM_PROMPT = """
You are an expert assessment item writer and JSON generator.

You generate high-quality multiple-choice assessment items for STEM examinations.

Core rules:
- Preserve the original item's topic, objective, difficulty, and cognitive demand.
- Do NOT merely translate the original item.
- Create new clone items with new surface features, contexts, or numbers.
- Maintain a single best correct answer.
- Use plausible distractors.
- Output valid JSON only.

For each generated clone, also return:
- diagram_required: true or false
- diagram_prompt: null if no diagram is needed

If diagram_required is true, write a short, precise diagram-generation prompt for an educational image model.
The prompt should describe a clean, exam-style diagram.
It must:
- be visually clear
- avoid decorative art
- avoid revealing the answer
- include only the needed labels and objects
- be suitable for a school assessment item
"""


def build_generation_prompt(
    item: SourceItem,
    style_examples: str,
    target_language: str = "English",
    n_clones: int = 2,
) -> str:
    return f"""
The original source item is in: {item.source_language}
The new generated items must be written in: {target_language}

Subject: {item.subject}
Exam: {item.exam}

Original item metadata:
- ID: {item.item_id}
- Difficulty: {item.difficulty}
- Grade: {item.grade}
- Section: {item.section}
- Topic: {item.topic}
- Objective: {item.objective}

Original stem:
{item.stem}

Original options:
A) {item.options.get("A", "")}
B) {item.options.get("B", "")}
C) {item.options.get("C", "")}
D) {item.options.get("D", "")}

Original correct answer:
{item.correct_answer}

Retrieved style examples from the same item bank:
{style_examples}

Task:
Generate EXACTLY {n_clones} new clone items.

Important:
- The source item may be in Russian, Kazakh, English, or another language.
- Understand the source item, but write the generated items only in {target_language}.
- Do not copy the original wording.
- Do not simply translate the original.
- Preserve difficulty level {item.difficulty}.
- Preserve the same underlying skill and cognitive demand.
- Use four options: A, B, C, D.
- Include a short rationale in {target_language}.
- Include a short difficulty_note in {target_language}.
- Set diagram_required to true only if a diagram, graph, circuit, force diagram, ray diagram, table, or figure is needed.

Return ONLY this JSON schema:

{{
  "clones": [
    {{
      "stem": "string in {target_language}",
      "options": {{
        "A": "string in {target_language}",
        "B": "string in {target_language}",
        "C": "string in {target_language}",
        "D": "string in {target_language}"
      }},
      "correct_option": "A",
      "cognitive_level": "recall|apply|reason",
      "difficulty_level": "{item.difficulty}",
      "difficulty_note": "short note in {target_language}",
      "rationale": "short explanation in {target_language}",
      "diagram_required": false
    }}
  ]
}}
"""


def generate_clones(
    item: SourceItem,
    style_examples: str,
    llm: AigraLLMClient,
    target_language: str = "English",
    n_clones: int = 2,
) -> List[GeneratedItem]:
    user_prompt = build_generation_prompt(
        item=item,
        style_examples=style_examples,
        target_language=target_language,
        n_clones=n_clones,
    )

    raw = llm.generate(
        system_prompt=GENERATOR_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.4,
        max_tokens=3000,
    )

    data = parse_json_object(raw)
    clones_raw = data.get("clones", [])

    clones: List[GeneratedItem] = []

    for clone in clones_raw:
        clone["source_language"] = item.source_language
        clone["target_language"] = target_language

        if "difficulty_level" not in clone or not clone["difficulty_level"]:
            clone["difficulty_level"] = item.difficulty

        clones.append(GeneratedItem(**clone))

    return clones
