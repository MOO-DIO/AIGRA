def _aigra_diagram_context_text(item):
    diagram_required = getattr(item, "diagram_required", False)
    diagram_prompt = getattr(item, "diagram_prompt", None)

    if diagram_required or diagram_prompt:
        return (
            "\n\nDIAGRAM CONTEXT FOR THIS ITEM:\n"
            f"diagram_required: {diagram_required}\n"
            f"diagram_prompt: {diagram_prompt or ''}\n"
            "When solving or reviewing this item, treat the diagram_prompt as part of the item. "
            "Do not reject the item merely because the stem says 'diagram below' if a detailed diagram_prompt is present.\n"
        )

    return ""


from typing import Dict, Any, Optional

from aigra_backend.schemas import GeneratedItem
from aigra_backend.llm_clients import AigraLLMClient
from aigra_backend.utils import parse_json_object


SOLVER_SYSTEM_PROMPT = """
You are a precise assessment item solver and answer-key verifier.

Your task:
- Solve the multiple-choice item independently.
- Do not trust any provided answer key.
- Compare all four options carefully.
- The selected answer label must match the selected option text.
- If none of the options is correct, return answer as null.
- If the item is ambiguous, return answer as null and set ambiguous to true.
- Return valid JSON only.
"""


def build_solver_prompt(
    clone: GeneratedItem,
    target_language: str = "English",
) -> str:
    return f"""
Solve the following multiple-choice item.

The item is written in: {target_language}

Stem:
{clone.stem}

Options:
A) {clone.options.get("A", "")}
B) {clone.options.get("B", "")}
C) {clone.options.get("C", "")}
D) {clone.options.get("D", "")}

Important:
- Evaluate A, B, C, and D one by one.
- The answer label must correspond exactly to the option text you believe is correct.
- If your reasoning points to "compression" but compression is not one of the options, do NOT choose another label.
- If no listed option is correct, return null.
- If the stem is unclear or has more than one defensible answer, return null and mark ambiguous true.

Return ONLY this JSON schema:

{{
  "answer": "A|B|C|D|null",
  "selected_option_text": "the exact option text selected, or null",
  "confidence": "high|medium|low",
  "ambiguous": true,
  "reasoning": "brief explanation"
}}
"""


def normalize_answer(answer: Optional[str]) -> Optional[str]:
    if answer is None:
        return None

    answer = str(answer).strip().upper()

    if answer in {"A", "B", "C", "D"}:
        return answer

    if answer in {"NULL", "NONE", "N/A", ""}:
        return None

    return None


def solve_clone(
    clone: GeneratedItem,
    llm: AigraLLMClient,
    target_language: str = "English",
) -> Dict[str, Any]:
    user_prompt = build_solver_prompt(
        clone=clone,
        target_language=target_language,
    )

    raw = llm.generate(
        system_prompt=SOLVER_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.0,
        max_tokens=1200,
    )

    data = parse_json_object(raw)

    answer = normalize_answer(data.get("answer"))
    selected_option_text = data.get("selected_option_text")
    reasoning = data.get("reasoning", "")
    confidence = data.get("confidence", "low")
    ambiguous = bool(data.get("ambiguous", False))

    expected_text = None
    if answer in {"A", "B", "C", "D"}:
        expected_text = clone.options.get(answer)

    return {
        "answer": answer,
        "selected_option_text": selected_option_text,
        "expected_option_text": expected_text,
        "confidence": confidence,
        "ambiguous": ambiguous,
        "reasoning": reasoning,
        "matches_key": answer == clone.correct_option,
    }


def attach_solver_result(
    clone: GeneratedItem,
    llm: AigraLLMClient,
    target_language: str = "English",
) -> GeneratedItem:
    result = solve_clone(
        clone=clone,
        llm=llm,
        target_language=target_language,
    )

    clone.solver_answer = result["answer"]
    clone.solver_reasoning = (
        f"Selected option text: {result['selected_option_text']}; "
        f"Expected option text: {result['expected_option_text']}; "
        f"Confidence: {result['confidence']}; "
        f"Ambiguous: {result['ambiguous']}; "
        f"Reasoning: {result['reasoning']}"
    )
    clone.solver_matches_key = result["matches_key"]

    return clone
