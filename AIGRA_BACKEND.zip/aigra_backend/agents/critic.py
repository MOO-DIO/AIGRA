def _aigra_diagram_context_text(item):
    diagram_required = getattr(item, "diagram_required", False)
    diagram_prompt = getattr(item, "diagram_prompt", None)

    if diagram_required or diagram_prompt:
        return (
            "\n\nDIAGRAM CONTEXT FOR THIS ITEM:\n"
            f"diagram_required: {diagram_required}\n"
            f"diagram_prompt: {diagram_prompt or ''}\n"
            "When solving or reviewing this item, treat the diagram_prompt as part of the item. "
            "Do not reject the item merely because the stem says 'diagram below' if a detailed diagram_prompt is present.\n"
        )

    return ""


import json
from typing import List

from aigra_backend.schemas import SourceItem, GeneratedItem
from aigra_backend.llm_clients import AigraLLMClient
from aigra_backend.utils import parse_json_object


CRITIC_SYSTEM_PROMPT = """
You are a senior assessment item reviewer and subject-matter expert.

Your task:
- Review generated multiple-choice assessment items.
- Check whether each item is valid, clear, complete, and aligned with the original source item.
- Check whether the generated item preserves topic, difficulty, objective, and cognitive demand.
- Check whether the item is too close to the original source item.
- Check whether the stem is complete.
- Check whether there is one best answer.
- Check whether the distractors are plausible.
- Check whether the solver result agrees with the generated answer key.
- Return valid JSON only.

Status rules:
- "ok": item is acceptable as written.
- "edited": item is mostly acceptable but needs minor revision.
- "reject": item has a serious flaw, such as incomplete stem, wrong key, ambiguity, solver mismatch, or near-copying.
"""


def build_critic_prompt(
    original_item: SourceItem,
    clones: List[GeneratedItem],
    target_language: str = "English",
    review_language: str = "English",
) -> str:
    clones_payload = []

    for i, clone in enumerate(clones, start=1):
        clones_payload.append(
            {
                "clone_index": i,
                "stem": clone.stem,
                "options": clone.options,
                "correct_option": clone.correct_option,
                "cognitive_level": clone.cognitive_level,
                "difficulty_level": clone.difficulty_level,
                "difficulty_note": clone.difficulty_note,
                "rationale": clone.rationale,
                "diagram_required": clone.diagram_required,
                "solver_answer": clone.solver_answer,
                "solver_matches_key": clone.solver_matches_key,
                "solver_reasoning": clone.solver_reasoning,
            }
        )

    clones_json = json.dumps(
        {"clones": clones_payload},
        ensure_ascii=False,
        indent=2,
    )

    return f"""
Original source item language: {original_item.source_language}
Generated item target language: {target_language}
Review comments must be written in: {review_language}

Original item metadata:
- ID: {original_item.item_id}
- Subject: {original_item.subject}
- Exam: {original_item.exam}
- Difficulty: {original_item.difficulty}
- Grade: {original_item.grade}
- Section: {original_item.section}
- Topic: {original_item.topic}
- Objective: {original_item.objective}

Original stem:
{original_item.stem}

Original options:
A) {original_item.options.get("A", "")}
B) {original_item.options.get("B", "")}
C) {original_item.options.get("C", "")}
D) {original_item.options.get("D", "")}

Original correct answer:
{original_item.correct_answer}

Generated clones to review:
{clones_json}

Review each clone carefully.

Important:
- Reject incomplete stems.
- Reject items where the solver answer does not match the generated key, unless the solver is clearly wrong.
- Reject items that are only translations or near-copies of the original.
- Reject ambiguous items.
- Mark as edited if the item is useful but needs small wording improvement.
- Mark as ok only if the item is ready for SME review.

Return ONLY this JSON schema:

{{
  "clones": [
    {{
      "clone_index": 1,
      "status": "ok|edited|reject",
      "review_comment": "brief review comment in {review_language}"
    }}
  ]
}}
"""


def review_clones(
    original_item: SourceItem,
    clones: List[GeneratedItem],
    llm: AigraLLMClient,
    target_language: str = "English",
    review_language: str = "English",
) -> List[GeneratedItem]:
    user_prompt = build_critic_prompt(
        original_item=original_item,
        clones=clones,
        target_language=target_language,
        review_language=review_language,
    )

    raw = llm.generate(
        system_prompt=CRITIC_SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.1,
        max_tokens=2000,
    )

    data = parse_json_object(raw)
    reviews = data.get("clones", [])

    review_lookup = {
        int(review.get("clone_index")): review
        for review in reviews
        if review.get("clone_index") is not None
    }

    reviewed_clones: List[GeneratedItem] = []

    for i, clone in enumerate(clones, start=1):
        review = review_lookup.get(i, {})

        clone.status = review.get("status", "reject")
        clone.review_comment = review.get(
            "review_comment",
            "No review comment returned by critic.",
        )

        reviewed_clones.append(clone)

    return reviewed_clones
