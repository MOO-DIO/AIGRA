from pathlib import Path
import re

from aigra_backend.image_clients import AigraImageClient


def build_diagram_prompt_from_clone(clone) -> str:
    stem = getattr(clone, "stem", "") or ""
    options = getattr(clone, "options", {}) or {}

    option_text = "; ".join(
        f"{label}) {text}" for label, text in options.items() if text
    )

    return (
        "Create a clean educational assessment diagram in simple black-and-white "
        "textbook line-art style. The diagram should support this item without "
        "revealing the answer. Use only necessary labels, arrows, objects, and "
        "measurements. Avoid decorative art and avoid extra explanation. "
        f"Item stem: {stem}. "
        f"Options, for context only and not to be shown as answers: {option_text}."
    )


def safe_filename(value: str, fallback: str = "diagram") -> str:
    value = str(value or "").strip()
    value = re.sub(r"[^A-Za-z0-9_-]+", "_", value)
    value = value.strip("_")
    return value[:80] or fallback


def render_clone_diagram(
    clone,
    image_provider: str = "openai",
    image_model: str = "gpt-image-1",
    output_dir: str = "outputs/diagrams",
    force: bool = False,
):
    """
    Generate and attach a diagram path for a clone.

    If clone.diagram_prompt is missing, a safe generic diagram prompt is built
    from the stem and options.
    """
    if not force and not getattr(clone, "diagram_required", False):
        return clone

    prompt = getattr(clone, "diagram_prompt", None)

    if not prompt:
        prompt = build_diagram_prompt_from_clone(clone)
        clone.diagram_prompt = prompt

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    safe = safe_filename(getattr(clone, "stem", "diagram"))
    output_path = out_dir / f"{safe}.png"

    client = AigraImageClient(
        provider=image_provider,
        model=image_model,
    )

    saved = client.generate_image(
        prompt=prompt,
        output_path=str(output_path),
    )

    clone.diagram_path = saved
    clone.image_provider = image_provider
    clone.image_model = image_model

    return clone
