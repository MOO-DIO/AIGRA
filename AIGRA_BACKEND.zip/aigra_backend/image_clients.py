from pathlib import Path
import base64
import os
from io import BytesIO


SUPPORTED_IMAGE_MODELS = {
    "gemini": [
        "gemini-2.5-flash-image",
        "gemini-3.1-flash-image-preview",
        "gemini-3-pro-image-preview",
    ],
    "openai": [
        "gpt-image-1",
    ],
}


def supported_image_models(provider=None):
    if provider is None:
        return SUPPORTED_IMAGE_MODELS

    provider = provider.lower().strip()
    return SUPPORTED_IMAGE_MODELS.get(provider, [])


def save_bytes_as_png(image_bytes, output_path):
    """
    Save arbitrary image bytes as a real PNG file.
    This handles Gemini returning JPEG/WebP/etc. while the requested path is .png.
    """
    from PIL import Image

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    image = Image.open(BytesIO(image_bytes))

    if image.mode not in ("RGB", "RGBA"):
        image = image.convert("RGBA")

    image.save(output_path, format="PNG")

    return str(output_path)


class AigraImageClient:
    """
    Multi-provider, multi-model image-generation client for AIGRA.

    Supported providers:
    - gemini
    - openai
    """

    def __init__(self, provider="gemini", model=None, api_key=None):
        self.provider = provider.lower().strip()
        self.api_key = api_key

        if self.provider == "gemini":
            from google import genai

            self.model = model or "gemini-2.5-flash-image"
            key = (
                api_key
                or os.getenv("GEMINI_API_KEY")
                or os.getenv("GOOGLE_API_KEY")
            )

            if not key:
                raise RuntimeError("GEMINI_API_KEY or GOOGLE_API_KEY is not set.")

            self.client = genai.Client(api_key=key)

        elif self.provider == "openai":
            from openai import OpenAI

            self.model = model or "gpt-image-1"
            key = api_key or os.getenv("OPENAI_API_KEY")

            if not key:
                raise RuntimeError("OPENAI_API_KEY is not set.")

            self.client = OpenAI(api_key=key)

        else:
            raise ValueError("Unsupported image provider. Use 'gemini' or 'openai'.")

    @staticmethod
    def supported_models(provider=None):
        return supported_image_models(provider)

    def generate_image(
        self,
        prompt: str,
        output_path: str,
        size: str = "1024x1024",
        output_format: str = "png",
    ) -> str:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if self.provider == "gemini":
            return self._generate_gemini_image(
                prompt=prompt,
                output_path=output_path,
            )

        if self.provider == "openai":
            return self._generate_openai_image(
                prompt=prompt,
                output_path=output_path,
                size=size,
                output_format=output_format,
            )

        raise ValueError(f"Unsupported image provider: {self.provider}")

    def _generate_gemini_image(self, prompt: str, output_path: Path) -> str:
        response = self.client.models.generate_content(
            model=self.model,
            contents=[prompt],
        )

        parts = getattr(response, "parts", None)

        if parts is None:
            candidates = getattr(response, "candidates", []) or []
            if candidates:
                content = getattr(candidates[0], "content", None)
                parts = getattr(content, "parts", None)

        if not parts:
            raise RuntimeError(f"Gemini model {self.model} returned no parts.")

        for part in parts:
            inline_data = getattr(part, "inline_data", None)

            if inline_data is not None:
                data = getattr(inline_data, "data", None)

                if data is None:
                    continue

                if isinstance(data, str):
                    image_bytes = base64.b64decode(data)
                else:
                    image_bytes = data

                # Always save as a true PNG so R png::readPNG() can read it.
                return save_bytes_as_png(image_bytes, output_path)

            if hasattr(part, "as_image"):
                try:
                    image = part.as_image()
                    image.save(output_path, format="PNG")
                    return str(output_path)
                except Exception:
                    pass

        text_parts = []
        for part in parts:
            text = getattr(part, "text", None)
            if text:
                text_parts.append(text)

        raise RuntimeError(
            f"Gemini model {self.model} did not return image data. "
            "Text returned: " + " ".join(text_parts)
        )

    def _generate_openai_image(
        self,
        prompt: str,
        output_path: Path,
        size: str = "1024x1024",
        output_format: str = "png",
    ) -> str:
        result = self.client.images.generate(
            model=self.model,
            prompt=prompt,
            size=size,
            output_format=output_format,
        )

        image_base64 = result.data[0].b64_json
        image_bytes = base64.b64decode(image_base64)

        return save_bytes_as_png(image_bytes, output_path)


def generate_image_with_fallback(
    prompt: str,
    output_path: str,
    provider: str = "gemini",
    models=None,
    size: str = "1024x1024",
) -> str:
    provider = provider.lower().strip()

    if models is None:
        models = SUPPORTED_IMAGE_MODELS.get(provider, [])

    if isinstance(models, str):
        models = [models]

    errors = []

    for model in models:
        try:
            client = AigraImageClient(
                provider=provider,
                model=model,
            )

            return client.generate_image(
                prompt=prompt,
                output_path=output_path,
                size=size,
            )

        except Exception as e:
            errors.append(f"{provider}/{model}: {e}")

    raise RuntimeError("All image models failed. " + " | ".join(errors))
