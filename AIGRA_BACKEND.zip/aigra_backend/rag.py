﻿from dataclasses import dataclass
from typing import List
import os

# Use locally cached HuggingFace models by default.
# This prevents repeated internet checks that can timeout.
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

from .schemas import SourceItem
from .config import DEFAULT_EMBEDDING_MODEL


@dataclass
class RetrievedExample:
    item_id: str
    score: float
    text: str


def clean_text(value) -> str:
    if value is None:
        return ""
    return str(value).strip().lower()


def metadata_boost(target: SourceItem, candidate: SourceItem) -> float:
    boost = 0.0

    if clean_text(target.topic) and clean_text(target.topic) == clean_text(candidate.topic):
        boost += 0.30

    if clean_text(target.section) and clean_text(target.section) == clean_text(candidate.section):
        boost += 0.20

    if clean_text(target.objective) and clean_text(target.objective) == clean_text(candidate.objective):
        boost += 0.25

    if clean_text(target.difficulty) and clean_text(target.difficulty) == clean_text(candidate.difficulty):
        boost += 0.10

    if clean_text(target.grade) and clean_text(target.grade) == clean_text(candidate.grade):
        boost += 0.05

    return boost


class AigraVectorStore:
    """
    Small FAISS-based vector store for AIGRA source items.
    """

    def __init__(
        self,
        items: List[SourceItem],
        embedding_model: str = DEFAULT_EMBEDDING_MODEL,
    ):
        if not items:
            raise ValueError("Cannot build vector store with an empty item list.")

        self.items = items
        self.item_lookup = {item.item_id: item for item in items}
        self.embedding_model_name = embedding_model

        try:
            self.model = SentenceTransformer(
                embedding_model,
                local_files_only=True,
            )
        except TypeError:
            # Older sentence-transformers versions may not support local_files_only.
            self.model = SentenceTransformer(embedding_model)

        self.texts = [item_to_rag_text(item) for item in items]

        embeddings = self.model.encode(
            self.texts,
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=True,
        )

        self.embeddings = embeddings.astype("float32")

        dim = self.embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(self.embeddings)

    def search(self, query: str, k: int = 3) -> List[RetrievedExample]:
        if not query.strip():
            raise ValueError("Search query cannot be empty.")

        k = min(k, len(self.items))

        query_embedding = self.model.encode(
            [query],
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        ).astype("float32")

        scores, indices = self.index.search(query_embedding, k)

        results: List[RetrievedExample] = []

        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue

            item = self.items[int(idx)]

            results.append(
                RetrievedExample(
                    item_id=item.item_id,
                    score=float(score),
                    text=self.texts[int(idx)],
                )
            )

        return results

    def search_for_item(
        self,
        item: SourceItem,
        k: int = 3,
        exclude_self: bool = True,
    ) -> List[RetrievedExample]:
        query = build_style_query(item)

        candidate_k = min(max(k * 10, 20), len(self.items))
        raw_results = self.search(query, k=candidate_k)

        reranked: List[RetrievedExample] = []

        for result in raw_results:
            candidate = self.item_lookup.get(result.item_id)

            if candidate is None:
                continue

            if exclude_self and candidate.item_id == item.item_id:
                continue

            new_score = result.score + metadata_boost(item, candidate)

            reranked.append(
                RetrievedExample(
                    item_id=result.item_id,
                    score=new_score,
                    text=result.text,
                )
            )

        reranked.sort(key=lambda x: x.score, reverse=True)

        return reranked[:k]


def item_to_rag_text(item: SourceItem) -> str:
    return "\n".join(
        [
            f"ID: {item.item_id}",
            f"Difficulty: {item.difficulty}",
            f"Grade: {item.grade}",
            f"Section: {item.section}",
            f"Topic: {item.topic}",
            f"Objective: {item.objective}",
            "",
            "Stem:",
            item.stem,
            "",
            "Options:",
            f"A) {item.options.get('A', '')}",
            f"B) {item.options.get('B', '')}",
            f"C) {item.options.get('C', '')}",
            f"D) {item.options.get('D', '')}",
            "",
            f"Correct answer: {item.correct_answer}",
        ]
    )


def build_vector_store(
    items: List[SourceItem],
    embedding_model: str = DEFAULT_EMBEDDING_MODEL,
) -> AigraVectorStore:
    return AigraVectorStore(items=items, embedding_model=embedding_model)


def build_style_query(item: SourceItem) -> str:
    return (
        "Assessment item with similar subject, topic, objective, difficulty, "
        f"and style. Subject section: {item.section}. "
        f"Topic: {item.topic}. "
        f"Objective: {item.objective}. "
        f"Difficulty: {item.difficulty}. "
        "Multiple-choice physics item with four options and one correct answer."
    )


def retrieve_style_examples(
    vector_store: AigraVectorStore,
    item: SourceItem,
    k: int = 3,
) -> str:
    results = vector_store.search_for_item(item, k=k, exclude_self=True)

    return "\n\n---\n\n".join(result.text for result in results)
