﻿from aigra_backend.schemas import GeneratedItem


BAD_ENDINGS = (
    "due to",
    "because",
    "causing",
    "undergo",
    "undergoes",
    "underwent",
    "by",
    "of",
    "to",
    "from",
    "with",
    "and",
    "or",
    "the",
    "a",
    "an",
)


def stem_looks_incomplete(stem: str) -> bool:
    if not stem:
        return True

    clean = stem.strip()
    lower = clean.lower().rstrip(".?!:;,")

    if len(clean.split()) < 8:
        return True

    return lower.endswith(BAD_ENDINGS)


def apply_rule_based_review(clone: GeneratedItem) -> GeneratedItem:
    """
    Apply deterministic safety checks after LLM critic review.

    These checks catch obvious issues such as incomplete stems or solver-key mismatch.
    """
    flags = []

    if stem_looks_incomplete(clone.stem):
        flags.append("The stem appears incomplete.")

    if clone.solver_matches_key is False:
        flags.append("The solver answer does not match the generated key.")

    if clone.correct_option not in {"A", "B", "C", "D"}:
        flags.append("The generated key is not one of A, B, C, or D.")

    for label in ["A", "B", "C", "D"]:
        if not clone.options.get(label):
            flags.append(f"Option {label} is missing.")

    if flags:
        clone.status = "reject"

        existing = clone.review_comment or ""
        rule_comment = " Rule-based review: " + " ".join(flags)

        clone.review_comment = (existing + rule_comment).strip()

    return clone
