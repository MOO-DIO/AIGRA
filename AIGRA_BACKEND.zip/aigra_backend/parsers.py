import re
from pathlib import Path
from typing import List, Optional

from pypdf import PdfReader

from .schemas import SourceItem


def extract_field(meta: str, name: str) -> Optional[str]:
    """Extract {Field} = value from a metadata block."""
    pattern = r"\{" + re.escape(name) + r"\}\s*=\s*(.*)"
    match = re.search(pattern, meta)
    if match:
        return match.group(1).strip()
    return None


def parse_kazakhstan_physics_pdf(
    pdf_path: str | Path,
    source_language: str = "Russian",
    subject: str = "Physics",
    exam: str = "Kazakhstan UNT"
) -> List[SourceItem]:
    """
    Parse Kazakhstan UNT/NST-style physics items from a PDF.

    The source bank may be Russian/Kazakh, but generated items can later
    be produced in any target language by the generator agent.
    """
    pdf_path = Path(pdf_path)

    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    reader = PdfReader(str(pdf_path))
    full_text = "\n".join(page.extract_text() or "" for page in reader.pages)

    chunks = re.split(r"###\s*-\s*", full_text)
    chunks = chunks[1:]

    items: List[SourceItem] = []

    for chunk in chunks:
        match_id = re.match(r"(\d+)\s*(.*)", chunk, re.S)
        if not match_id:
            continue

        item_id = match_id.group(1).strip()
        body = match_id.group(2)

        meta_idx = body.find("{Разработчик}")
        if meta_idx == -1:
            continue

        stem_opts_text = body[:meta_idx].strip()
        meta_text = body[meta_idx:].strip()

        match_a = re.search(r"\nA\)\s*", stem_opts_text)
        if not match_a:
            match_a = re.search(r"A\)\s*", stem_opts_text)
        if not match_a:
            continue

        stem_text = stem_opts_text[:match_a.start()].strip()
        options_block = stem_opts_text[match_a.start():]

        def extract_option(letter: str) -> str:
            pattern = rf"{letter}\)\s*(.+?)(?=\n[ABCD]\)|$)"
            match = re.search(pattern, options_block, re.S)
            if not match:
                return ""
            return " ".join(match.group(1).split())

        options = {
            "A": extract_option("A"),
            "B": extract_option("B"),
            "C": extract_option("C"),
            "D": extract_option("D"),
        }

        correct_raw = extract_field(meta_text, "Правильный ответ") or ""
        correct_answer = correct_raw.strip()[:1] or "A"

        item = SourceItem(
            item_id=item_id,
            stem=" ".join(stem_text.split()),
            options=options,
            correct_answer=correct_answer,
            difficulty=extract_field(meta_text, "Трудность"),
            grade=extract_field(meta_text, "Класс"),
            section=extract_field(meta_text, "Раздел"),
            topic=extract_field(meta_text, "Тема"),
            objective=extract_field(meta_text, "Цель"),
            raw_metadata=meta_text,
            source_language=source_language,
            subject=subject,
            exam=exam,
        )

        items.append(item)

    return items

def parse_tabular_item_bank(
    file_path,
    source_language="English",
    subject="General",
    exam="Item Bank",
):
    """
    Parse assessment items from a CSV or Excel item bank.
    """
    import pandas as pd
    from pathlib import Path

    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"Item bank file not found: {file_path}")

    suffix = file_path.suffix.lower()

    if suffix == ".csv":
        df = pd.read_csv(file_path)
    elif suffix in {".xlsx", ".xls"}:
        df = pd.read_excel(file_path)
    else:
        raise ValueError("Unsupported file type. Use .csv, .xlsx, or .xls.")

    df.columns = [str(col).strip() for col in df.columns]

    required = [
        "stem",
        "option_A",
        "option_B",
        "option_C",
        "option_D",
        "correct_answer",
    ]

    missing = [col for col in required if col not in df.columns]

    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))

    def get_value(row, name, default=None):
        if name not in row:
            return default

        value = row[name]

        if pd.isna(value):
            return default

        return str(value).strip()

    items = []

    for idx, row in df.iterrows():
        item_id = get_value(row, "item_id", str(idx + 1))

        options = {
            "A": get_value(row, "option_A", ""),
            "B": get_value(row, "option_B", ""),
            "C": get_value(row, "option_C", ""),
            "D": get_value(row, "option_D", ""),
        }

        item = SourceItem(
            item_id=item_id,
            stem=get_value(row, "stem", ""),
            options=options,
            correct_answer=get_value(row, "correct_answer", "A")[:1].upper(),
            difficulty=get_value(row, "difficulty"),
            grade=get_value(row, "grade"),
            section=get_value(row, "section"),
            topic=get_value(row, "topic"),
            objective=get_value(row, "objective"),
            raw_metadata=(
                    f"source_diagram_required={get_value(row, 'source_diagram_required', '')}\n"
                    f"source_diagram_path={get_value(row, 'source_diagram_path', '')}\n"
                    f"source_diagram_caption={get_value(row, 'source_diagram_caption', '')}\n"
                    f"source_diagram_type={get_value(row, 'source_diagram_type', '')}"
                ),
            source_language=get_value(row, "source_language", source_language),
            subject=get_value(row, "subject", subject),
            exam=get_value(row, "exam", exam),
        )

        items.append(item)

    return items

def parse_tabular_item_bank_with_errors(
    file_path,
    source_language="English",
    subject="General",
    exam="Item Bank",
):
    """
    Parse CSV/Excel item bank and return:
    - valid SourceItem objects
    - invalid row records with reasons

    Missing required columns stop the whole file.
    Invalid individual rows are reported and skipped.
    """
    import pandas as pd
    from pathlib import Path

    file_path = Path(file_path)

    if not file_path.exists():
        raise FileNotFoundError(f"Item bank file not found: {file_path}")

    suffix = file_path.suffix.lower()

    if suffix == ".csv":
        df = pd.read_csv(file_path)
    elif suffix in {".xlsx", ".xls"}:
        df = pd.read_excel(file_path)
    else:
        raise ValueError("Unsupported file type. Use .csv, .xlsx, or .xls.")

    df.columns = [str(col).strip() for col in df.columns]

    required = [
        "stem",
        "option_A",
        "option_B",
        "option_C",
        "option_D",
        "correct_answer",
    ]

    missing = [col for col in required if col not in df.columns]

    if missing:
        raise ValueError("Missing required columns: " + ", ".join(missing))

    def get_value(row, name, default=""):
        if name not in row:
            return default

        value = row[name]

        if pd.isna(value):
            return default

        return str(value).strip()

    duplicate_ids = set()

    if "item_id" in df.columns:
        ids = [str(x).strip() for x in df["item_id"].fillna("")]
        duplicate_ids = {
            x for x in ids
            if x and ids.count(x) > 1
        }

    valid_items = []
    invalid_rows = []

    for idx, row in df.iterrows():
        row_number = idx + 2
        item_id = get_value(row, "item_id", f"ROW_{idx + 1}")

        reasons = []

        stem = get_value(row, "stem", "")
        if not stem:
            reasons.append("empty stem")

        options = {
            "A": get_value(row, "option_A", ""),
            "B": get_value(row, "option_B", ""),
            "C": get_value(row, "option_C", ""),
            "D": get_value(row, "option_D", ""),
        }

        for label, value in options.items():
            if not value:
                reasons.append(f"missing option_{label}")

        correct_answer = get_value(row, "correct_answer", "").upper()[:1]

        if correct_answer not in {"A", "B", "C", "D"}:
            reasons.append("correct_answer must be A, B, C, or D")

        if item_id in duplicate_ids:
            reasons.append("duplicate item_id")

        row_source_language = get_value(row, "source_language", source_language)
        row_subject = get_value(row, "subject", subject)
        row_exam = get_value(row, "exam", exam)

        if reasons:
            invalid_rows.append(
                {
                    "row_number": row_number,
                    "item_id": item_id,
                    "reasons": reasons,
                    "stem": stem,
                    "options": options,
                    "correct_answer": correct_answer or "A",
                    "difficulty": get_value(row, "difficulty", None),
                    "grade": get_value(row, "grade", None),
                    "section": get_value(row, "section", None),
                    "topic": get_value(row, "topic", None),
                    "objective": get_value(row, "objective", None),
                    "source_language": row_source_language,
                    "subject": row_subject,
                    "exam": row_exam,
                }
            )
            continue

        valid_items.append(
            SourceItem(
                item_id=item_id,
                stem=stem,
                options=options,
                correct_answer=correct_answer,
                difficulty=get_value(row, "difficulty", None),
                grade=get_value(row, "grade", None),
                section=get_value(row, "section", None),
                topic=get_value(row, "topic", None),
                objective=get_value(row, "objective", None),
                raw_metadata=(
                    f"source_diagram_required={get_value(row, 'source_diagram_required', '')}\n"
                    f"source_diagram_path={get_value(row, 'source_diagram_path', '')}\n"
                    f"source_diagram_caption={get_value(row, 'source_diagram_caption', '')}\n"
                    f"source_diagram_type={get_value(row, 'source_diagram_type', '')}"
                ),
                source_language=row_source_language,
                subject=row_subject,
                exam=row_exam,
            )
        )

    return valid_items, invalid_rows


def parse_tabular_item_bank(
    file_path,
    source_language="English",
    subject="General",
    exam="Item Bank",
):
    """
    Parse only valid tabular items.

    Invalid rows are skipped. Use parse_tabular_item_bank_with_errors()
    to inspect invalid rows.
    """
    valid_items, invalid_rows = parse_tabular_item_bank_with_errors(
        file_path=file_path,
        source_language=source_language,
        subject=subject,
        exam=exam,
    )

    return valid_items
